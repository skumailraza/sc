package hibernate;

import org.hibernate.*;
/**
 * Created by Kumail on 3/29/17.
 */
public class Java {

}
